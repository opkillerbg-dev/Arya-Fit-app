function say(t,f){try{if(!f&&PR.voi===0)return;if(ENG&&ENG.speak){if(TM&&TM.eng&&!f&&document.hidden)return;ENG.speak({text:t}).catch(function(){});return}if(!window.speechSynthesis)return;var y=speechSynthesis;if(y.speaking||y.pending)y.cancel();var u=new SpeechSynthesisUtterance(t);u.lang="en-US";y.speak(u)}catch(e){}}
function phaseFx(x){var d=$("dock");d.classList.remove("ax-dflip");void d.offsetWidth;d.classList.add("ax-dflip");setTimeout(function(){d.classList.remove("ax-dflip")},600);say(x=="w"?"Walk now.":"Jog now.")}
function cel(dy,msg){var g=(st["g"+dy]||0)/1000,el=document.createElement("div");el.id="cel";el.innerHTML='<svg viewBox="0 0 52 52"><circle cx="26" cy="26" r="24"/><path d="M14 27l9 9 16-18"/></svg><b>'+(g?"0.00":"Saved")+'</b><span>'+(g?"km logged today":"")+'</span>';document.body.appendChild(el);
  var b=el.querySelector("b");if(g&&!RM){var t0=performance.now();(function f(n){var q=Math.min(1,(n-t0)/900);b.textContent=(g*(1-Math.pow(1-q,3))).toFixed(2);if(q<1)requestAnimationFrame(f)})(t0)}else if(g)b.textContent=g.toFixed(2);
  if(g&&!msg)burst(innerWidth/2,innerHeight/2,60);hx("finish");el.onclick=function(){el.remove()};setTimeout(function(){el.remove()},2600)}
var rqd=0;
/* v95: smart reminder. Schedules the next 7 days one by one with that day's workout name. Rest days, finished days and days with no time left are skipped; it stops by itself if the app is not opened for a week. Re-planned whenever the app opens or is left. */
function remind(q){if(!LN){if(!q)toast("Reminders work in the phone app.");return}
  try{var ids=[],k;for(k=0;k<8;k++)ids.push({id:9+k});LN.cancel({notifications:ids});var v=PR.rmt;if(!v)return;
  if(!rqd||!q){rqd=1;LN.requestPermissions()}
  LN.createChannel({id:"rem",name:"Daily reminder",importance:3});
  var hh=+v.split(":")[0],mm=+v.split(":")[1],now=new Date(),t0=todayIdx(),list=[];
  for(k=0;k<7;k++){var i=t0+k;if(i<0||i>=ND)continue;var src=axSrc(i);if(src<0||st["x"+i]==1)continue;var c=cnt(i);if(c[1]&&c[0]>=c[1])continue;
    var at=new Date(now.getFullYear(),now.getMonth(),now.getDate()+k,hh,mm,0);if(at<=now)continue;var tt=T[wdk(src)];
    list.push({id:9+k,channelId:"rem",title:k?"Workout day":"Time to move",body:((tt&&tt.n)||"Your workout")+". Ready when you are.",schedule:{at:at,allowWhileIdle:true}})}
  if(list.length)LN.schedule({notifications:list});
  if(!q)toast(list.length?"Reminder set for "+v:"No workout days left to remind")}catch(e){}}
function pextra2(g,td){td=Math.max(0,td);var W=Math.floor(Math.min(td,ND-1)/7),sum=function(w){var a=0;for(var i=w*7;i<w*7+7&&i<ND;i++)a+=g[i]||0;return a},dn=0,rs=0,jt=0,wk=0,i;
  for(i=W*7;i<W*7+7&&i<ND;i++){if(dayDone(i)||st["x"+i]==2)dn++;if(st["x"+i]==1)rs++;jt+=st["jt"+i]||0;wk+=st["wk"+i]||0}
  var a=sum(W),b=W?sum(W-1):0,df=W&&b?Math.round((a-b)/b*100):null,
  h='<div class="panel"><h3 style="margin-top:0">This week</h3><div class="wsum"><div><b>'+a.toFixed(1)+'</b>km</div><div><b>'+dn+'/7</b>days done'+(rs?' | '+rs+' rest':'')+'</div><div><b>'+(jt+wk?Math.round(jt/(jt+wk)*100)+"%":"--")+'</b>jog share</div></div>'+(df==null?'':'<p class="key">'+(df>=0?'Up ':'Down ')+Math.abs(df)+'% in distance vs last week.</p>')+'</div>',pts=[];
  for(i=0;i<ND;i++)if(g[i]>=.5&&st["r"+i])pts.push(st["r"+i]/g[i]);
  if(pts.length>1){var lo=Math.min.apply(0,pts),hi=Math.max.apply(0,pts),sp=hi-lo||1,d=pts.map(function(p,k){return(k*280/(pts.length-1)).toFixed(1)+","+(10+(p-lo)/sp*60).toFixed(1)}).join(" ");
    h+='<div class="panel"><h3 style="margin-top:0">Pace trend</h3><svg viewBox="0 0 280 80" style="width:100%"><polyline points="'+d+'" style="fill:none;stroke:var(--blue);stroke-width:2.5;stroke-linejoin:round"/></svg><p class="key">'+fmt(pts[0])+' to '+fmt(pts[pts.length-1])+' per km. Higher on the chart means faster.</p></div>'}
  return h}
function lvl(){return Math.max(0,Math.min(IVS.length-1,PR.lvl==null?Math.floor(Dn()/7):PR.lvl))}
function brk(){if(PR.lrd!=null&&PR.lvl>0&&Dn()-PR.lrd>=7){PR.lvl--;PR.lrd=Dn();save();toast("Back after a break: easing one level.")}}
function adapt(d,dy){if(!JKM||!d.trk)return;var tt=(d.jt||0)+(d.wt||0);if(tt<120)return;var tot=(st["g"+dy]||0)/1000,L=lvl(),q=IVS[L],pj=q[1]?q[0]/(q[0]+q[1]):1,r=(d.jt||0)/tt/pj,n=L,t;
  if(tot>=JKM*.98&&r>=.9&&L<IVS.length-1){n=L+1;t="Level up. Next run: "+ivt(n)+"."}else if(r<.6&&L>0){n=L-1;t="Easing back. Next run: "+ivt(n)+"."}else t="Same level next run: "+ivt(L)+".";
  PR.lvl=n;PR.lrd=dy;save();clearTimeout(adT);adT=setTimeout(function(){toast(t)},2800)}
function saveRoute(dy,rt){if(!rt||rt.length<5)return;var n=rt.length,sp=Math.ceil(n/250),o=[];for(var i=0;i<n;i+=sp)o.push(rt[i]);if(o[o.length-1]!==rt[n-1])o.push(rt[n-1]);var R=axRoutes();(R[dy]=R[dy]||[]).push(o);save()}
function pextra3(){var R=axRoutes();if(!R)return"";var ds=Object.keys(R).map(Number).sort(function(a,b){return a-b}),dk=ds[ds.length-1];if(dk==null)return"";var pts=R[dk][R[dk].length-1];if(!pts||pts.length<5)return"";
  var kx=Math.cos(pts[0][0]*Math.PI/180),xs=pts.map(function(p){return p[1]*kx}),ys=pts.map(function(p){return -p[0]}),mnx=Math.min.apply(0,xs),mxx=Math.max.apply(0,xs),mny=Math.min.apply(0,ys),mxy=Math.max.apply(0,ys),sc=Math.min(260/((mxx-mnx)||1e-6),170/((mxy-mny)||1e-6)),ox=(280-(mxx-mnx)*sc)/2,oy=(190-(mxy-mny)*sc)/2+5,
  X=function(i){return(ox+(xs[i]-mnx)*sc).toFixed(1)},Y=function(i){return(oy+(ys[i]-mny)*sc).toFixed(1)},sp=[],cum=0,spl=[],nk=1,lt=pts[0][2],h="",i;
  for(i=1;i<pts.length;i++){var d=hav({la:pts[i-1][0],lo:pts[i-1][1]},{la:pts[i][0],lo:pts[i][1]}),t2=(pts[i][2]-pts[i-1][2])/1000;sp.push(t2>0?d/t2:0);cum+=d;if(cum>=nk*1000){spl.push(fmt((pts[i][2]-lt)/1000));lt=pts[i][2];nk++}}
  var s2=sp.slice().sort(function(a,b){return a-b}),lo=s2[Math.floor(s2.length*.1)],hi=s2[Math.floor(s2.length*.9)]||1;
  for(i=1;i<pts.length;i++){var f=Math.max(0,Math.min(1,(sp[i-1]-lo)/((hi-lo)||1)));h+='<line x1="'+X(i-1)+'" y1="'+Y(i-1)+'" x2="'+X(i)+'" y2="'+Y(i)+'" style="stroke:hsl('+Math.round(f*120)+',85%,50%);stroke-width:4;stroke-linecap:round"/>'}
  return '<div class="panel"><h3 style="margin-top:0">Run map, '+dl(dk)+'</h3><svg viewBox="0 0 280 200" style="width:100%"><g>'+h+'<circle cx="'+X(0)+'" cy="'+Y(0)+'" r="5" style="fill:#fff;stroke:#000"/><circle cx="'+X(pts.length-1)+'" cy="'+Y(pts.length-1)+'" r="5" style="fill:var(--sun);stroke:#000"/></g></svg><p class="key">Red is slower, green is faster. White dot is the start.</p>'+(spl.length?'<p class="key">Per km: '+spl.map(function(t,k){return(k+1)+" = "+t}).join(" | ")+'</p>':'')+'<button class="btn w" id="sh-go">Share run card</button></div>'}
var GW=[["Neck and shoulder rolls",30],["Arm circles",30],["Hip circles",30],["Leg swings",40],["Walking lunges",40],["High knees march",40],["Ankle bounces",30]],GC=[["Slow walk",60],["Quad stretch",30],["Hamstring stretch",30],["Calf stretch",30],["Hip flexor stretch",30],["Chest and shoulder stretch",30],["Deep breathing",30]],gtm=0,mt=0;
function gsess(L){var i=0,t=0,o=document.createElement("div");o.id="gov";document.body.appendChild(o);
  function end(){clearInterval(gtm);o.remove()}
  function show(){if(i>=L.length){end();say("Done");return}t=L[i][1];say(L[i][0]);o.innerHTML='<small>'+(i+1)+' of '+L.length+'</small><b>'+L[i][0]+'</b><i>'+t+'</i><div class="qr" style="gap:10px"><button class="btn" id="gk">Skip</button><button class="btn" id="gx">Close</button></div>';$("gk").onclick=function(){i++;show()};$("gx").onclick=end}
  clearInterval(gtm);show();gtm=setInterval(function(){t--;var e=o.querySelector("i");if(e)e.textContent=t;if(t<=0){i++;show()}},1000)}
function apz(on){if(on&&TM.run){TM.acc+=Date.now()-TM.last;TM.run=false;TM.aps=1;TM.apl=null;$("dpp").textContent="Resume";toast("Auto-paused")}else if(!on&&!TM.run&&TM.aps){TM.last=Date.now();TM.run=true;TM.aps=0;TM.lm=Date.now();$("dpp").textContent="Pause"}}
function metro(){clearTimeout(mt);try{if(PR.met&&TM&&TM.mode=="iv"&&TM.run&&!(TM.hold||TM.ph))tick()}catch(e){}var _on=PR.met&&TM&&TM.mode=="iv"&&TM.run;mt=setTimeout(metro,!PR.met?2000:(_on?60000/Math.max(100,Math.min(220,PR.spm||160)):500))}
function theme(){var h=document.documentElement,activeSkin=PR.skin||"oldmoney";if(activeSkin!=="classic")h.setAttribute("data-skin",activeSkin);else h.removeAttribute("data-skin");document.querySelectorAll(".sk").forEach(function(b){b.classList.toggle("on",activeSkin==b.dataset.k)});h.classList.toggle("amo",!!PR.amo);h.classList.toggle("gls",!!PR.gls);if(PR.acc)h.style.setProperty("--blue",PR.acc);else h.style.removeProperty("--blue");syncSystemBarStyle()}
